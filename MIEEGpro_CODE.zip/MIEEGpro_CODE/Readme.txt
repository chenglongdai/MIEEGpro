
Run AutoSearching_main.m